history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
vi /etc/hostname
cat /etc/hostname
reboot
apt-get update
vi /etc/apt/sources.list
apt-get update
apt-get upgrade
cat /etc/debian_version
vi /etc/apt/sources.list
ls
tar -xzvf Material_Adicional_TPVMCA.tar.gz
ls
apt-get update
apt-get upgrade
cat /etc/debian_version
reboot
apt-get install openssh-server
systemctl sshd
systemctl status sshd
ssh-keygen
cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
vi /etc/ssh/sshd_config
systemctl restart ssh
systemctl status sshd
apt-get install apache2
hostname
apt-get install mariadb-server
systemctl status apache2
systemctl status mariadb
ls
ls -l
vi /etc/network/interfaces
reboot
ip a
vi /etc/network/interfaces
ip a
vi /etc/network/interfaces
reboot
ip a
ifup enp0s3
vi /etc/network/interfaces
apt-get update
vi /etc/apt/sources.list
vi /etc/network/interfaces
reboot
cat /etc/apt/sources.list
apt-get update
vi /etc/apt/sources.list
apt-get update
vi /etc/apt/sources.list
apt-get update
vi /etc/apt/sources.list
apt-get update
reboot
ssh-copy id root@192.168.1.220
ssh-copy id root@192.168.1.255
ssh-copy-id 192.168.1.220
logout
