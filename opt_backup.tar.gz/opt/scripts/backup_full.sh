#!/bin/bash

#opcion de ayuda (pto5)
if [ "$1" == "-help" ]; then
	echo "Uso: /opt/scripts/backup_full.sh [origen] [destino]"
	echo "Ejemplo: /opt/scripts/backup_full.sh /var/log /backup_dir"
	exit 0
fi

#Validar que el usuario ingrese exactamente 2 argumentos (pto4)
if [ $# -ne 1 ]; then
	echo "Error: Se requieren 2 agumentos (origen y destino)."
	echo "Use -help para ver el manual de uso."
	exit 1
fi

ORIGEN=$1
DESTINO="/backup_dir"
FECHA=$(date +%Y%m%d)
NOMBRE_DIR=$(basename "$ORIGEN")


#Validacion de existencia (el oriden y destino deben existir) pto6
if [ ! -d "$ORIGEN" ]; then
	echo "Error: El directorio de origen $ORIGEN no existe."
	exit 1
fi

if [ ! -d "$DESTINO" ]; then
	echo "Error: El directorio de destino $DESTINO no existe."
	exit 1
fi

#Realizar backup comprimido Pto 2 y 3
tar -cvzf "$DESTINO/${NOMBRE_DIR}_bkp_$FECHA.tar.gz" "$ORIGEN"
